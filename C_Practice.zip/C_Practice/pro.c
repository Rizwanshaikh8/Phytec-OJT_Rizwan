#include<stdio.h>
int main()
{
	for (int a=0;a<2;a++)
	{
		a=a+1;
		printf("%d",a);
	}
}

