#ifndef _LIB_H
#define _LIB_H

int add(int quant1,int quant2);
int sub(int quant1,int quant2);
int mul(int quant1,int quant2);
int div(int quant1,int quant2);
void  print(char *string,inttime);


#endif
