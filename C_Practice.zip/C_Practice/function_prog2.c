#include<stdio.h>
#include<math.h>
int main()
{
	float r=3;
	float a,b,c,d;
	a=sin(r);
	b=cos(r);
	c=tan(r);
	d=pow(r,3);
	printf("%f %f %f %f",a,b,c,d);
	return 0;
}

