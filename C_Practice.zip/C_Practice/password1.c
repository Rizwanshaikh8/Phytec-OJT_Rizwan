#include<stdio.h>
int main()
{
	int a=0,b=0;
	while (a<=100,b<=100)
	{
		printf("%d,%d",a,b);
		a++;
		b++;
	}
}

