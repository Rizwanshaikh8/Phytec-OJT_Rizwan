
#include<stdio.h>
int main()
{
	int a=2,b=2,c;
	c=a+b;
	printf("c %d+%d=%d",a,b,c);
	return 0;
}
	

	
	
