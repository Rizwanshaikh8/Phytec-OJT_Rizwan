#include<stdio.h>
#include<math.h>
int main()
{
	int a,b,sum,sub,div,mul;
	printf("enter the number a and b");
	scanf("%d %d",&a,&b);
	sum=a+b;
	sub=a-b;
	div=a/b;
	mul=a*b;
	printf("sum of two number %d\n",sum);
	printf("sub of two number %d\n",sub);
	printf("multiple of two number %d\n",mul);
	printf("division of two number %d\n",div);



}

