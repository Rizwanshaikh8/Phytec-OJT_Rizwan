#include<stdio.h>
int main()
{
	int a=10;
	a=a+33;
	a=a-12;
	a=a*31;
	printf("hello harish");
}

