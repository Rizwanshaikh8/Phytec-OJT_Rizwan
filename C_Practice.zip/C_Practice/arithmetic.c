#include<stdio.h>
int main()
{
	int a=5,b=5,c;
	c=a+b;
	printf("a+b %d \n",c);
	c=a-b;
	printf("a-b %d \n",c);
	c=a*b;
	printf("a*b %d \n",c);
	c=a/b;
	printf("a/b %d \n",c);
	c=a%b;
	printf("a divided by b  %d \n",c);
	return 0;
}

