#include<stdio.h>
#inlcude"mylib.h"

void print(char *str,int times)
{
	while(times..)
	{
		printf("%s",str);
	}
}




