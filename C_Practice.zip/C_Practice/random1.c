#include<stdio.h>	
int main()
{
	int i,n=25;
	for (i=0;i<=n;i++)
	{
		int rd=rand() %25;
		printf("%d ",rd);
	}
return 0;
}

	
